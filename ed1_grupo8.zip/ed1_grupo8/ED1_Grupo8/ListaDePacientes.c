#include"ListaDePacientes.h"


int verificarListaVazia(ListaDePacientes *lista)
{
	if(lista->paciente.nome == NULL )
		return 1;
	return 0;
}

ListaDePacientes *criarLista(ListaDePacientes *lista)
{
    ListaDePacientes *elemento;    
	lista = (ListaDePacientes *)calloc(1, sizeof(ListaDePacientes));

    lista->proximo = NULL;

    return lista;
}

ListaDePacientes *inserirPaciente(ListaDePacientes *lista, Paciente paciente)
{
	
	if(verificarListaVazia(lista))
	{
		lista->paciente = paciente;
		return lista;	
	}	
	
    ListaDePacientes *elemento, *ptr;
    elemento = (ListaDePacientes *)malloc(sizeof(ListaDePacientes));

    elemento->paciente = paciente;
    elemento->proximo = NULL;
    ptr = lista;
    while(ptr->proximo != NULL)
        ptr = ptr->proximo;
    ptr->proximo = elemento;
    return lista;

}

ListaDePacientes *removerPrimeiroPaciente(ListaDePacientes *lista)
{
    ListaDePacientes *ptr;
    ptr = lista;
    lista = lista->proximo;
    free(ptr);
    return lista;
}

ListaDePacientes *removerPaciente(ListaDePacientes *lista, char *nome)
{
	short isIgual = 0;
    ListaDePacientes *elemento, *ptr;
    ptr = lista;
    if(strcmp(ptr->paciente.nome, nome) == 0)
    {
        lista = removerPrimeiroPaciente(lista);
        return lista;
    }
    else
    {

    	do
    	{
    		if(strcmp(ptr->paciente.nome, nome) == 0)
    			isIgual = 1;
    		if(isIgual)
    			break;
    		elemento = ptr;
            ptr = ptr->proximo;
		}
        while(!isIgual && ptr != NULL);

		if(isIgual)
        {
			elemento->proximo = ptr->proximo;
	        free(ptr);
	        return lista;
		}
		return lista;
    }
}

ListaDePacientes *substituirPaciente(ListaDePacientes *lista, char *pacienteASubstituir, char *pacienteQueVaiSubstituir)
{
 	short isIgualQueVaiSubstituir = 0;
	 short isIgualASubstituir = 0;
    ListaDePacientes *ptr, *elemento, *ptr2, *elemento2;
    ptr = lista;
    ptr2 = lista;

    do
    {
    	if(strcmp(ptr->paciente.nome, pacienteASubstituir) == 0)
    		isIgualASubstituir = 1;
    	if(isIgualASubstituir)
    		break;
    	elemento = ptr;
        ptr = ptr->proximo;
        
	} while(!isIgualASubstituir && ptr != NULL);
        
    do
    {
    	if(strcmp(ptr2->paciente.nome, pacienteQueVaiSubstituir) == 0)
    		isIgualQueVaiSubstituir = 1;
    	if(isIgualQueVaiSubstituir)
    		break;
    	elemento2 = ptr2;
        ptr2 = ptr2->proximo;
        
	} while(!isIgualQueVaiSubstituir && ptr != NULL);         

	if(isIgualASubstituir && isIgualQueVaiSubstituir)
    {
	    elemento2->proximo = ptr2->proximo;
	    elemento->proximo = ptr2;
	    ptr2->proximo = ptr->proximo;
	    free(ptr);
	    return lista;
	}

	return lista;
}

void actualizarPaciente(ListaDePacientes *lista, int telefone)
{
    Paciente *paciente = buscarPaciente(telefone, lista);
    char *nome = (char *)malloc(50 * sizeof(char));
    char *endereco = (char *)malloc(70 * sizeof(char));
    char *medico = (char *)malloc(50 * sizeof(char));
    if(paciente == NULL)
        printf("Paciente Inexistente!");
    else
    {
		
    	printf("Introduza o nome: ");
    	fflush(stdin);
		gets(nome);
		paciente->nome = nome;
    
    	printf("Introduza a idade: ");
		scanf("%d", &paciente->idade);
    	
		printf("Introduza o telefone: ");
		scanf("%d", &paciente->telefone);
		
		printf("Introduza o endereco: ");
		fflush(stdin);
		gets(endereco);
		paciente->endereco = endereco;
		
		printf("Introduza o medico: ");
		fflush(stdin);
		gets(medico);
		paciente->medico = medico;
		
    }
}


Paciente *buscarPaciente(int telefone, ListaDePacientes *lista)
{
  	ListaDePacientes *ptr = lista;
    short isIgual = 0;
    
    do
    {
    	if(ptr->paciente.telefone == telefone)
    		isIgual = 1;
    	if(isIgual)
    		break;
        ptr = ptr->proximo;
	}
    while(!isIgual && ptr != NULL);

	if(isIgual)
    {
		return &ptr->paciente;
	}
	return NULL;
}


int contarPacientesNaLista(ListaDePacientes *lista)
{
	ListaDePacientes *ptr = lista;
	int count = 0;
	while(ptr->proximo != NULL)
    {
    	ptr = ptr->proximo;
    	count++;
	}
	return ++count;
}

int pacientesComOMesmoMedico(ListaDePacientes *lista, char *medico)
{
    if(lista->proximo == NULL)
       return strcmp(lista->paciente.medico, medico) == 0 ? 1 : 0;

    else
    {
    	if((strcmp(lista->paciente.medico, medico) == 0) && lista->proximo != NULL)
        	return 1  + pacientesComOMesmoMedico(lista->proximo, medico);
        else
        	return pacientesComOMesmoMedico(lista->proximo, medico);
    }
}

