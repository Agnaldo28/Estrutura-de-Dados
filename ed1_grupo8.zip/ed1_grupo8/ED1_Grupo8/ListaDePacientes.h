#include<string.h>
#include<stdlib.h>
#include<stdio.h>


 typedef struct
{

    char *nome;
    int telefone;
    short int idade;
    char *endereco;
    char *medico;

} Paciente;

typedef struct Lista
{
    Paciente paciente;
    struct Lista *proximo;
} ListaDePacientes;

int contarPacientesNaLista(ListaDePacientes *lista);
int verificarListaVazia(ListaDePacientes *lista);
ListaDePacientes *criarLista(ListaDePacientes *lista);

ListaDePacientes *inserirPaciente(ListaDePacientes *lista, Paciente paciente);

ListaDePacientes *removerPaciente(ListaDePacientes *lista, char *nome);

Paciente preencherPaciente();

ListaDePacientes *substituirPaciente(ListaDePacientes *lista, char *pacienteASubstituir, char *pacienteQueVaiSubstituir);

void actualizarPaciente(ListaDePacientes *lista, int telefone);

int pacientesComOMesmoMedico(ListaDePacientes *lista, char *medico);

ListaDePacientes limparLista(ListaDePacientes *lista);


Paciente *buscarPaciente(int telefone, ListaDePacientes *lista);

ListaDePacientes *removerPrimeiroPaciente(ListaDePacientes *lista);











