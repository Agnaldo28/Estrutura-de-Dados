#include"Mensagem.h"
#include <windows.h>


int vermelha = 4;

void apresentarMensagemInicial()
{	
	mostraCursor(1);
   	alterarCorDaConsola(DOURADO);
   	system("cls");
	printf("\t\t  ______ _____ _____ _    _             _____  ______  \n");
	printf("\t\t |  ____|_   _/ ____| |  | |   /\\      |  __ \\|  ____|\n");
	printf("\t\t | |__    | || |    | |__| |  /  \\     | |  | | |__    \n");
	printf("\t\t |  __|   | || |    |  __  | / /\\ \\    | |  | |  __|   \n");
	printf("\t\t | |     _| || |____| |  | |/ ____ \\   | |__| | |____   \n");
	printf("\t\t |_|    |_____\\_____|_|  |_/_/    \\_\\  |_____/|______| \n");
	

	alterarCorDaConsola(BRANCO);
	printf("\t .########.....###.....######..####.########.##....##.########.########..######.\n");
	printf("\t .##.....##...##.##...##....##..##..##.......###...##....##....##.......##....##\n");
	printf("\t .##.....##..##...##..##........##..##.......####..##....##....##.......##......\n ");
	printf("\t .########..##.....##.##........##..######...##.##.##....##....######....######.\n");
	printf("\t .##........#########.##........##..##.......##..####....##....##.............##\n");
	printf("\t .##........##.....##.##....##..##..##.......##...###....##....##.......##....##\n");
	printf("\t .##........##.....##..######..####.########.##....##....##....########..######.\n");
}

void apresentarMensagemListaVazia()
{
	apresentarMensagemInicial();
	alterarCorDaConsola(TABELA_CINZA);
	printf("\t\t\t\t!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
	printf("\t\t\t\t!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
	printf("\t\t\t\t!!!!!!!!!!");
	alterarCorDaConsola(VERMELHO);
	printf("LISTA VAZIA !");
	alterarCorDaConsola(TABELA_CINZA);
	printf("!!!!!!!!!!\n");
	printf("\t\t\t\t!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
	printf("\t\t\t\t!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");

	
	alterarCorDaConsola(TABELA_DOURADA);
	printf("\n\n");
	printf("\t\t\t");	
	system("echo PRESSIONE QUALQUER TECLA PARA VOLTAR A TELA INICIAL");
	mostraCursor(0);
	alterarCorDaConsola(BRANCO);
	system("pause > null");
}

void apresentarMensagemListaComElementos(int elementos)
{
	apresentarMensagemInicial();
	alterarCorDaConsola(TABELA_DOURADA );
	printf("\t\t\t\t.................................\n");
	printf("\t\t\t\t.................................\n");
	printf("\t\t\t\t......");
	alterarCorDaConsola(VERDE);
	printf("%d PACIENTES NA LISTA ", elementos);
	alterarCorDaConsola(TABELA_DOURADA );
	printf("......\n");
	printf("\t\t\t\t.................................\n");
	printf("\t\t\t\t.................................\n");

	
	alterarCorDaConsola(TABELA_DOURADA);
	printf("\n\n");
	printf("\t\t\t");	
	system("echo PRESSIONE QUALQUER TECLA PARA VOLTAR A TELA INICIAL");
	mostraCursor(0);
	alterarCorDaConsola(BRANCO);
	system("pause > null");
}

void apresentarMensagemPacientesComMesmoMedico(int medicos)
{
	apresentarMensagemInicial();
	alterarCorDaConsola(TABELA_DOURADA );
	printf("\t\t\t...........................................\n");
	printf("\t\t\t...........................................\n");
	printf("\t\t\t......");
	alterarCorDaConsola(VERDE);
	printf("%d PACIENTES COM O MESMO MEDICO ", medicos);
	alterarCorDaConsola(TABELA_DOURADA );
	printf("......\n");
	printf("\t\t\t...........................................\n");
	printf("\t\t\t...........................................\n");

	
	alterarCorDaConsola(TABELA_DOURADA);
	printf("\n\n");
	printf("\t\t          ");	
	system("echo PRESSIONE QUALQUER TECLA PARA VOLTAR A TELA INICIAL");
	mostraCursor(0);
	alterarCorDaConsola(BRANCO);
	system("pause > null");
}

void apresentarMensagemListaInicializada()
{
	apresentarMensagemInicial();
	alterarCorDaConsola(TABELA_DOURADA );
	printf("\t\t\t\t.................................\n");
	printf("\t\t\t\t.................................\n");
	printf("\t\t\t\t......");
	alterarCorDaConsola(VERDE);
	printf(" LISTA INICIALIZADA ");
	alterarCorDaConsola(TABELA_DOURADA );
	printf("......\n");
	printf("\t\t\t\t.................................\n");
	printf("\t\t\t\t.................................\n");

	
	alterarCorDaConsola(TABELA_DOURADA);
	printf("\n\n");
	printf("\t\t\t");	
	system("echo PRESSIONE QUALQUER TECLA PARA VOLTAR A TELA INICIAL");
	mostraCursor(0);
	alterarCorDaConsola(BRANCO);
	system("pause > null");
}

void apresentarLista(ListaDePacientes *lista)
{
	apresentarMensagemInicial();
	ListaDePacientes *ptr;
	int count = 1;
	ptr = lista;
	
	while(ptr != NULL)
	{
		if(count % 2 == 0)
		{
			alterarCorDaConsola(TABELA_DOURADA);
			printf("                      ##.. %s |", ptr->paciente.nome);
			printf(" %d |",ptr->paciente.idade);
			printf(" %d |",  ptr->paciente.telefone);
			printf(" %s |",  ptr->paciente.endereco);
			printf(" %s .##                               \n",  ptr->paciente.medico);
		}
		else
		{
			alterarCorDaConsola(TABELA_CLARA);
			printf("                      ##.. %s |", ptr->paciente.nome);
			printf(" %d |",ptr->paciente.idade);
			printf(" %d |",  ptr->paciente.telefone);
			printf(" %s |",  ptr->paciente.endereco);
			printf(" %s .##                               \n",  ptr->paciente.medico);
		}
		count++;
		ptr = ptr->proximo;
	}
	
	alterarCorDaConsola(TABELA_DOURADA);
	printf("\n\n");
	printf("\t\t\t");	
	system("echo PRESSIONE QUALQUER TECLA PARA VOLTAR A TELA INICIAL");
	mostraCursor(0);
	alterarCorDaConsola(DOURADO);
	
	system("pause > null");
}

void mostraCursor(int mostrar)
{
    HANDLE consola = GetStdHandle(STD_OUTPUT_HANDLE);

    CONSOLE_CURSOR_INFO   infoCursor;

    GetConsoleCursorInfo(consola, &infoCursor);
    infoCursor.bVisible = mostrar;
    SetConsoleCursorInfo(consola, &infoCursor);
}

void alterarCorDaConsola(COR cor)
{
	HANDLE consola;
	consola = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(consola, cor);
}

void apresentarTelaIncial()
{	
	apresentarMensagemInicial();
	alterarCorDaConsola(BRANCO);	
	
	printf(".###############################################################################################.\n");
	printf(".##..");
	alterarCorDaConsola(TABELA_CLARA);
	printf("Inicializar Lista         ");
	alterarCorDaConsola(TABELA_DOURADA);
	printf("- 1 -");
	alterarCorDaConsola(BRANCO);
	printf(".#####################..");
	alterarCorDaConsola(TABELA_CLARA);
	printf("Verificar Lista Vazia       ");
	alterarCorDaConsola(TABELA_DOURADA);
	printf("- 2 -");
	alterarCorDaConsola(BRANCO);
	printf(".##.\n");
	
	printf(".##..");
	alterarCorDaConsola(TABELA_DOURADA);
	printf("Inserir Paciente          ");
	alterarCorDaConsola(TABELA_CLARA);
	printf("- 3 -");
	alterarCorDaConsola(BRANCO);
	printf(".#####################..");
	alterarCorDaConsola(TABELA_DOURADA);
	printf("Remover Paciente            ");
	alterarCorDaConsola(TABELA_CLARA);
	printf("- 4 -");
	alterarCorDaConsola(BRANCO);
	printf(".##.\n");

	printf(".##..");
	alterarCorDaConsola(TABELA_CLARA);
	printf("Substituir Paciente       ");
	alterarCorDaConsola(TABELA_DOURADA);
	printf("- 5 -");
	alterarCorDaConsola(BRANCO);
	printf(".#####################..");
	alterarCorDaConsola(TABELA_CLARA);
	printf("Actualizar Paciente         ");
	alterarCorDaConsola(TABELA_DOURADA);
	printf("- 6 -");
	alterarCorDaConsola(BRANCO);
	printf(".##.\n");
	
	printf(".##..");
	alterarCorDaConsola(TABELA_DOURADA);
	printf("Pacientes com mesmo Medico");
	alterarCorDaConsola(TABELA_CLARA);
	printf("- 7 -");
	alterarCorDaConsola(BRANCO);
	printf(".#####################..");
	alterarCorDaConsola(TABELA_DOURADA);
	printf("Medico com mais Ocorrencias ");
	alterarCorDaConsola(TABELA_CLARA);
	printf("- 8 -");
	alterarCorDaConsola(BRANCO);
	printf(".##.\n");
	printf(".###############################################################################################.\n");
	printf("########MENU: ");
}
